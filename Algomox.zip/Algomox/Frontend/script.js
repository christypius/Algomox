async function getUsers() {
    let response = await fetch('http://localhost:1234/api');
    let data = await response.json();
    console.log(data);

    return data;
}

async function renderUsers() {
    let users = await getUsers();
    let html = '';
    users.forEach(user => {
        let htmlSegment = ` <div class="card m-3"  style="width: 18rem;">
                                <div class="card-body">
                                    <h5 class="card-title" id="name">${user.Name}</h5>
                                    <p class="card-text" id="role"> ${user.Role}</p>
                                    <p class="card-text text-info" > Skills </p>
                                    <p class="card-text" id="skill">${user.Skills}</p>
                                </div>
                            </div>`;

        html += htmlSegment;
    });

    let container = document.getElementById('cards');
    container.innerHTML = html;
}

renderUsers();