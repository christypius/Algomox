package main

import (
	"encoding/json"
	"fmt"
	"log"
	"os"
	"strings"

	"github.com/boltdb/bolt"
	"github.com/gin-gonic/gin"
	yaml "gopkg.in/yaml.v2"
)

type (
	Jobs struct {
		Role string
	}

	Role struct {
		Skills []string
	}

	Candidate struct {
		Name string
		Role string
	}

	CandidateDetails struct {
		Name   string
		Role   string
		Skills []string
	}
)

const (
	Addr       = "localhost:1234"
	dbLocation = "./job.db"
	filepath   = "./test.yaml"
)

var db *bolt.DB

func main() {

	// read file
	fmt.Println("Starting server")
	fileData, err := os.ReadFile(filepath)
	if err != nil {
		fmt.Println(err)
	}
	fmt.Print(string(fileData))

	// open DB
	db, err = bolt.Open(dbLocation, 0600, nil)
	if err != nil {
		log.Fatal(err)
	}
	defer db.Close()

	// create buckets
	err = CreateBucket()
	if err != nil {
		fmt.Println(err)
	}

	// store the file content to the structure
	data := make(map[interface{}]map[interface{}]interface{})

	err = yaml.Unmarshal(fileData, &data)
	if err != nil {
		fmt.Println(err)
	}

	// insert data to db
	for key, value := range data {
		// fmt.Printf("%s -> %s\n", key.(string), value)
		switch key.(string) {

		case "Candidates":
			fmt.Println("Candidates")
			fmt.Println(value)

			for innerKey, innerValue := range value {
				fmt.Println("inserting", innerKey, innerValue)
				// store to the DB
				err := StoreToDB("CANDIDATES", innerKey.(string), innerValue.(string))
				if err != nil {
					fmt.Println("err")
				}
			}

		case "Skills":
			fmt.Println("Skills")
			fmt.Println(value)
			for innerKey, innerValue := range value {

				fmt.Println("inserting", innerKey, innerValue)
				// store to the DB
				err := StoreToDB("SKILLS", innerKey.(string), innerValue.(string))
				if err != nil {
					fmt.Println("err")
				}
			}

		case "Jobs":
			fmt.Println("Jobs")
			fmt.Println(value)
			for innerKey, innerValue := range value {
				fmt.Println("inserting", innerKey, innerValue)

				// store to the DB
				err := StoreToDB("JOBS", innerKey.(string), innerValue.(string))
				if err != nil {
					fmt.Println("err")
				}
			}
		}
	}

	// APIs
	r := gin.Default()
	r.GET("/api", GetCandidates)

	// run routes
	if err := r.Run(Addr); err != nil {
		log.Printf("Error: %v", err)
	}
}

// create bucket
func CreateBucket() error {
	// create buckets
	err := db.Update(func(tx *bolt.Tx) error {
		_, err := tx.CreateBucketIfNotExists([]byte("JOBS"))
		if err != nil {
			fmt.Println("could not create Jobs bucket: %v", err)
		}
		_, err = tx.CreateBucketIfNotExists([]byte("SKILLS"))
		if err != nil {
			fmt.Println("could not create Skills bucket: %v", err)
		}
		_, err = tx.CreateBucketIfNotExists([]byte("CANDIDATES"))
		if err != nil {
			fmt.Println("could not create Candidates bucket: %v", err)
		}
		return err
	})
	if err != nil {
		fmt.Println("could not set up buckets, %v", err)
	}
	fmt.Println("DB Setup Done")
	return err
}

// store data to DB
func StoreToDB(bucket, key, value string) error {

	// Store the user model in the user bucket using the username as the key.
	err := db.Update(func(tx *bolt.Tx) error {
		bucket, err := tx.CreateBucketIfNotExists([]byte(bucket))
		if err != nil {
			return err
		}

		return bucket.Put([]byte(key), []byte(value))
	})
	return err
}

// get candidate details api handler
func GetCandidates(ginCtx *gin.Context) {
	fmt.Println("GetCandidates")

	ginCtx.Writer.Header().Set("Access-Control-Allow-Origin", "*")

	candidateMap := make(map[string]CandidateDetails)

	// vew db data
	err := db.Update(func(tx *bolt.Tx) error {

		fmt.Println("in tx")

		bucket, err := tx.CreateBucketIfNotExists([]byte("CANDIDATES"))
		if err != nil {
			return err
		}

		// Iterate over items in sorted key order.
		if err := bucket.ForEach(func(key, value []byte) error {

			var candidate CandidateDetails

			candidate.Name = string(key)
			candidate.Role = string(value)
			candidateMap[string(key)] = candidate

			return nil
		}); err != nil {
			return err
		}
		fmt.Println("candidateMap : ", candidateMap)

		for key, value := range candidateMap {

			var candidate CandidateDetails

			bucket, err := tx.CreateBucketIfNotExists([]byte("JOBS"))
			if err != nil {
				return err
			}

			roleName := bucket.Get([]byte(value.Role))
			fmt.Printf("roleName: %s\n", roleName)

			candidate = candidateMap[key]
			candidate.Role = string(roleName)

			candidateMap[key] = candidate

		}

		for key, value := range candidateMap {

			var candidate CandidateDetails

			bucket, err := tx.CreateBucketIfNotExists([]byte("SKILLS"))
			if err != nil {
				return err
			}

			roleData := bucket.Get([]byte(value.Role))
			fmt.Printf("roleData: %s\n", roleData)

			candidate = candidateMap[key]
			candidate.Skills = append(candidate.Skills, strings.Split(string(roleData), ",")...)

			candidateMap[key] = candidate

		}

		return nil
	})
	if err != nil {
		fmt.Println(err)
	}

	var candidateList []CandidateDetails

	for _, value := range candidateMap {
		candidateList = append(candidateList, value)
	}

	finalCandidateListJSON, err := json.Marshal(candidateList)
	if err != nil {
		fmt.Println(err)
	}

	ginCtx.String(200, string(finalCandidateListJSON))
}
